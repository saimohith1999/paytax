export const environment = {
  production: true,

  
 firebase:{
  apiKey: "AIzaSyBuCDE13dH2UylpmJUg4MGR9eH65_Il-Og",
  authDomain: "employee-e3565.firebaseapp.com",
  projectId: "employee-e3565",
  storageBucket: "employee-e3565.appspot.com",
  messagingSenderId: "181831600144",
  appId: "1:181831600144:web:d0f7f148e077cad9dca295",
  measurementId: "G-0HV9J4NNJD"
}

};
